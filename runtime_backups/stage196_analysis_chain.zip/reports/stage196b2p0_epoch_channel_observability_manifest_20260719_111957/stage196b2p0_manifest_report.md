# Stage196-B2-P0 epoch-channel observability manifest

## Decision

`STAGE196B2P0_EPOCH_CHANNEL_OBSERVABILITY_MANIFEST_READY`

## Run closure

Exact order: seed183_joint, seed183_frame_local_only, seed184_joint, seed184_frame_local_only, seed185_joint, seed185_frame_local_only.

Each argv array preserves the Stage196-B1 configuration and adds only the new
observability flag and new output root. Every run expects 20 sidecars of 720 rows.

## No-extra-forward contract

The sidecars reuse the existing clean-dev epoch evaluation output. No extra model
forward, gradient, loss, optimizer, output, or checkpoint-selection change is authorized.

## Provenance

Original Stage196-B1 runtime: `9835cbbf86d83aca0964821669e63f7f6deb1c59`.
Stage196-B2-P0 runtime: `e9aaff24054f1d409119b70df13b94159a34a8e4`.
FrameGate implementation origin: `5a39538ef3ca8f36cc2cc5d3290eae60d6a5f5c8`.

No prediction equivalence is claimed before execution.
